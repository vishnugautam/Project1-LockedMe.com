package mainMenu;

public interface Repeats {
	public  void display();
//	static final String FIRSTPRIZE = "Gold";
	public String location();
}
